package Clases

class Goomba: Enemy("Goomba", 1){
    //(name: String, strength: Int):
    //Enemy(name,strength) {
    //Enemy("Goomba",1) {
    init {
        println("Iniciando subclase de $name")
    }
}