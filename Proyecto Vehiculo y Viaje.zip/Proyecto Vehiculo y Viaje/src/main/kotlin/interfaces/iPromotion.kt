package interfaces

interface iPromotion {
    val discount: Int //El descuento en porcentaje o en cantidad
    val typeDiscount: Int //Porcentaje o cantidad

    fun getDiscountPrice(amount: Int): Int {//obtener el precio real ya con el descuento
        return if (typeDiscount == 0) {
            (amount * (100 - discount)) / 100
        } else { //cantidad especifica
            amount - discount
        }
    }
}