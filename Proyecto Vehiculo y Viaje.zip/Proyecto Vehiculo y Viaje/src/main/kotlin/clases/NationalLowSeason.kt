package clases

import interfaces.iPromotion

class NationalLowSeason(city: String) : National(city), iPromotion {
    override val discount = 10 //es porcentaje, es 10%
    override val typeDiscount = 0 //0 para porcenraje, 1 para cantidad

    override fun getPrice(numDays: Int): Int {
        val amount = super.getPrice(numDays)
        return if (amount == 0) 0 else getDiscountPrice(amount)
    }
}