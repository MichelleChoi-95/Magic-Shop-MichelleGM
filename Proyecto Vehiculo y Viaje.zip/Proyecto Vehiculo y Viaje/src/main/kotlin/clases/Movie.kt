package clases

data class Movie(val name: String, val gender: String, val duration: Double){
    var createAt=""
}

