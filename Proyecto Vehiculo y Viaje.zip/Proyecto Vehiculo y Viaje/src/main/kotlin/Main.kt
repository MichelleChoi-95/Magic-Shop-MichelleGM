import clases.*

fun main() {

   fun pruebita(precio: Double, cupon:Double, )

   fun calculadora(a:Int, b:Int, operacion:(Int, Int) -> Int): Int {
       return operacion(a, b)
   }
    fun suma(a: Int, b: Int)  = a + b
    fun resta(a: Int, b: Int)  = a - b
    fun multiplicacion(a: Int, b: Int)  = a * b

    val suma = calculadora(5,6,::suma)
    println(suma)
    val resta = calculadora(5,6,::resta)
    println(resta)
    val multiplicacion = calculadora(5,6,::multiplicacion)
    println(multiplicacion)
}